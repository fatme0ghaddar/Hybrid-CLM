% =========================================================================
% summary_table.m  –  build CEC‑2017 function summary (fitness + time)
% -------------------------------------------------------------------------
% • looks for   CEC2017_F*_logs.mat   files in logFolder
% • ignores any file that does not contain both  all_fitness  &  all_time
% • writes one Excel sheet:  CEC2017_Function_Summary.xlsx
% -------------------------------------------------------------------------
% 2025‑04‑19  –  indexing bug fixed (columns, not rows)
% 2025‑04‑20  –  robust to extra *.mat files (e.g. Full_Comparison_Logs.mat)
% =========================================================================

%% user path --------------------------------------------------------------
logFolder = 'C:\Users\fatoo\Desktop\Thesis\Codes\COA-s-code-main\COA-s-code-main\COA';
logFiles  = dir(fullfile(logFolder,'CEC2017_F*_logs.mat'));

algorithms = {'COA','Hybrid','LSHADE','MPA','WOA','SFO'};
% -------------------------------------------------------------------------

summaryData = {};
row = 1;

for k = 1:numel(logFiles)
    fileName = logFiles(k).name;
    fullPath = fullfile(logFolder,fileName);

    % quickly check contents
    mf   = matfile(fullPath);
    vars = who(mf);

    if ~all(ismember({'all_fitness','all_time'},vars))
        fprintf('⚠️  Skipping %s  (expected variables not found)\n',fileName);
        continue
    end

    funcName = regexp(fileName,'F\d+','match','once');   % e.g. 'F7'

    for algIdx = 1:numel(algorithms)
        fitness_vals = mf.all_fitness(:,algIdx);         % COLUMN = runs
        time_vals    = mf.all_time   (:,algIdx);

        % convert ms‑logs → s (heuristic threshold)
        if median(time_vals,'omitnan') > 200
            time_vals = time_vals / 1000;
        end

        summaryData(row,:) = {funcName, algorithms{algIdx}, ...
            min(fitness_vals,[],'omitnan'), ...
            max(fitness_vals,[],'omitnan'), ...
            mean(fitness_vals,'omitnan'), ...
            median(fitness_vals,'omitnan'), ...
            std(fitness_vals,0,'omitnan'), ...
            mean(time_vals,'omitnan')};

        row = row + 1;
    end
end

%% export -----------------------------------------------------------------
summaryTable = cell2table(summaryData, ...
    'VariableNames',{'Function','Algorithm','Best','Worst', ...
                     'Mean','Median','Std','Avg_Time'});

outFile = fullfile(logFolder,'CEC2017_Function_Summary.xlsx');
writetable(summaryTable,outFile);

fprintf('\n✅ Summary table written to:\n   %s\n', outFile);
